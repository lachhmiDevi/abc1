﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GradeBookApplication
{
    class StudentDataReadWrite : IEnumerable<Student>
    {
        //declare a list 
        private List<Student> _studentMarksList;

      
    public StudentDataReadWrite()
    {
        _studentMarksList = new List<Student>();

    }
        public Student this[int idx]
        {
            get
            {
                //return desired data.
                return _studentMarksList.ElementAt(idx);
            }
            set
            {
                //set desired data using the "value" parameter

                _studentMarksList.Add(value);
            }
        }
            //this method reads from the file 

            public void ReadFromFile(string path)
        {
            FileStream fileStream = null;

            try
            {
                fileStream = new FileStream(path, FileMode.OpenOrCreate, FileAccess.Read);

                StreamReader streamReader = new StreamReader(fileStream);
                while(streamReader.Peek() != -1)
                {
                    string record = streamReader.ReadLine();
                    string[] fields = record.Split(',');
                    _studentMarksList.Add(new Student(fields[0], fields[1], int.Parse(fields[2]),int.Parse(fields[3]), int.Parse(fields[4]), int.Parse(fields[5]),int.Parse(fields[6]),fields[7] ));
                }
                Console.WriteLine("THE READ OPERATION HAS ENDED ");
            }

            catch (FileNotFoundException)
            {
                MessageBox.Show(path + " not found.", "File Not Found");
            }
            catch (IOException ex)
            {
                MessageBox.Show(ex.Message, "IOExcaption");
            }

            finally
            {
                if(fileStream != null)
                {
                    fileStream.Close();

                }
            }
        }

        //this method writes the records to the file 

        public void WriteToFile(string path)
        {
            FileStream fileStream = null;
            StreamWriter streamWriter = null;

            try
            {
                fileStream = new FileStream(path, FileMode.Create, FileAccess.Write);
                streamWriter = new StreamWriter(fileStream);

                foreach (Student student in _studentMarksList)
                {
                    streamWriter.WriteLine(student.FirstName + "   " + student.LastName+"    "+student.Exam1+"   "+student.Exam2+"  "+student.Exam3+"  "+student.final+ "  "+student._average+" " + student._grade);
                }

                Console.WriteLine("Write is done ");

            }
            catch (FileNotFoundException)
            {
                MessageBox.Show(path + "not found.", "File Not Found");

            }
            catch(IOException ex)
            {
                MessageBox.Show(ex.Message, "IOException");
            }
            finally
            {
                if(streamWriter != null)
                {
                    streamWriter.Close(); //closing the writer
                   
                }
            }

        }
        public IEnumerator<Student> GetEnumerator()
        {
            return _studentMarksList.GetEnumerator();
        }

        System.Collections.IEnumerator System.Collections.IEnumerable.GetEnumerator()
        {
            return GetEnumerator();
        }
        }
}
