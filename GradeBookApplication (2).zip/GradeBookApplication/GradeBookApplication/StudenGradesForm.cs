﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Collections;


namespace GradeBookApplication
{
    public partial class StudenGradesForm : Form
    {

        public StudenGradesForm()
        {
            InitializeComponent();
        }

        // declare and Initialize list of Student class
        private static List<Student> list = new List<Student>();


        //Initialize list of strings _items 
        List<string> _items = new List<string>();

       
        // getter and setter to read the value in the field 
        internal static List<Student> List
        {
            get => list;
            set => list = value;
        }

        /// <summary>
        /// Method to add values of textboxes of StudentGradeForm to the lisbox of the ClassGradeForm
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
   
        public void OnClickAdd(object sender, EventArgs e)
        {
           //Object of the first Form 
            ClassGradesForm form1Obj = new ClassGradesForm();


            //object of the Student class that will use to assign  the value of textboxes 
            //to the  to the property  of Student class
            Student sObj = new Student();


            sObj.FirstName = _txtFirstName.Text;
            sObj.LastName = _txtLastName.Text;
            sObj.Exam1 = int.Parse((_txtExam1.Text).ToString());
            sObj.Exam2 = int.Parse((_txtExam2.Text).ToString());
            sObj.Exam3 = int.Parse((_txtExam3.Text).ToString());
            sObj.final = int.Parse((_txtFinal.Text).ToString());

            //Add all information to the List
            List.Add(sObj);
            //To show the form ClassGradeForm
            form1Obj.Show();
            //To hide the current information
            this.Hide();


            //to clear  values of text boxes 
            this._txtFirstName.Clear();
            this._txtLastName.Clear();
            this._txtExam1.Clear();
            this._txtExam2.Clear();
            this._txtExam3.Clear();
            this._txtFinal.Clear();

            //to set the focus of the textboxes when the form load 
            this.ActiveControl = _txtExam1;
            this.ActiveControl = _txtExam2;
            this.ActiveControl = _txtExam3;
            this.ActiveControl = _txtFinal;
            this.ActiveControl = _txtFirstName;
            this.ActiveControl = _txtLastName;
          

        }

        

        

        
    }
}
