﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GradeBookApplication
{
   
    class Student
    {
        public string _firstName;
        public string _lastName;
        public int _exam1;
        public int _exam2;
        public int _exam3;
        public int _finalExam;
        public string _grade;
        public int _average;

        //Student Constructor 
        public Student()
        {

        }

        public Student(string firstName, string lastName, int exam1, int exam2, int exam3, int finalExam, int average, string grade)
        {
            _firstName = firstName;
            _lastName = lastName;
            _exam1 = exam1;
            _exam2 = exam2;
            _exam3 = exam3;
            _finalExam = finalExam;
            _average = average;
            _grade = grade;
                           
        }

        public string FirstName
        {
            get;
            set;

        }


        public string LastName
        {
            get;
            set;

        }


        public int Exam1
        {
            get;
            set;

        }
        public int Exam2
        {
            get;
            set;

        }

        public int Exam3
        {
            get;
            set;
        }
        public int final
        {
            get;
            set;
        }

        //CONSTRUCTOR 
        //public Student(string first, string last, int ex1, int ex2, int ex3, int final)
       // {
           // _firstName = first;
            //_lastName = last;
            //_exam1 = ex1;
            //_exam2 = ex2;
            //_exam3 = ex3;
            //_finalExam = final;

        //}
        /// <summary>
        /// METHOD TO CALCULATE AVERAGE OF EXAMS 
        /// </summary>
        /// <returns></returns>
        private int CalculateAvg()
        {
            _average = ((_exam1 + _exam2 + _exam3 + _finalExam)/4);
            return _average;
        }



        public string CalculateLetAverage()
        {

            if (_average > 90)
            {
                return "A+";
            }
            else if (_average < 90 || _average >= 85)
            {
                return "A";
            }
            else if (_average < 80 || _average >= 75)
            {
                return "B+";

            }
            else if (_average < 75 || _average >= 70)
            {
                return "B";

            }
            else if (_average < 70 || _average >= 65)
            {
                return "C+";

            }
            else if (_average < 65 || _average >= 60)
            {
                return "D+";
            }
            else
                return "d";
        }


       

    /// <summary>
    /// 
    /// TO STRING METHOD TO DISPLAY THE VALUES 
    /// </summary>
    /// <returns></returns>
    public override string ToString()
        {
            return _firstName + "    " + _lastName + "     " + "     " + _exam1 + "    " +_exam2+"    "+ _exam3 + "    " + "    " + _finalExam+"      " + _average+"    " +_grade;
        }

      
    }
}
