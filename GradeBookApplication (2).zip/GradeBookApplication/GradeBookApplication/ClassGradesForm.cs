﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GradeBookApplication
{
    public partial class ClassGradesForm : Form
    {
        //declaration new objects  form and readAnd Write file 
        private StudenGradesForm _stdGradeForm;
        private StudentDataReadWrite  _stdReadWriteFile;

        public ClassGradesForm()
        {
            InitializeComponent();
            _stdGradeForm = new StudenGradesForm();
            _stdReadWriteFile = new StudentDataReadWrite();

        }

        //load form list into student class list 
        private List<Student> list = StudenGradesForm.List;

        //Method to 
        private void ClassGradesForm_Load(object sender, EventArgs e)
        {
            
          //  List<Student> sd1 = new List<Student>();
            int s = list.Count; // count of the list
            for(int i =0; i<s; i++)
            {  
                _studentMarksList.Items.Add(list[i].FirstName + "         " + list[i].LastName + "                  \t" + list[i].Exam1.ToString() + "                    \t" + list[i].Exam2.ToString() + "                   \t" + list[i].Exam3.ToString() + "                   \t" + list[i].final.ToString() );
            }
        }

        /// <summary>
        /// method to add the textboxes values into the listbox of the firstform
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void OnClickAdd(object sender, EventArgs e)
        {
            this.Hide();
           _stdGradeForm.Show();
        }


        private void OpenFileDialog1_FileOk(object sender, CancelEventArgs e)
        {

        }

        /// <summary>
        /// Method to save the record into the file
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void OnClickSave(object sender, EventArgs e)
        {
            SaveFileDialog saveFileDlg = new SaveFileDialog();
            if(saveFileDlg.ShowDialog() == DialogResult.OK)
            {
                StreamWriter writer = new StreamWriter(saveFileDlg.FileName);
                for (int i = 0; i < _studentMarksList.Items.Count; i++)
                {
                    writer.WriteLine((string)_studentMarksList.Items[i]);

                }
                writer.Close();

            }
            saveFileDlg.Dispose();

        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void OnDoubleClick(object sender, EventArgs e)
        {
            this.Hide();
            _stdGradeForm.Show();

        }

        /// <summary>
        /// method to exit from the form
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void OnClickExit(object sender, EventArgs e)
        {
            this.Close();

        }

        /// <summary>
        /// method to open the file 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void OnClickOpen(object sender, EventArgs e)
        {
            openFileDialog1.Filter = "txt files (*.txt)|*.txt";
            openFileDialog1.InitialDirectory =
                Path.Combine(Path.GetDirectoryName(Directory.GetCurrentDirectory())); ;
            DialogResult result = openFileDialog1.ShowDialog();
                if(result == DialogResult.OK)
            {
                string fileName = openFileDialog1.FileName;
                _stdReadWriteFile.ReadFromFile(fileName);
            }
                  foreach(Student student in StudenGradesForm.List)
            {
                _studentMarksList.Items.Add(student.ToString());

            }
        }

        /// <summary>
        /// method to calculate the grades 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void OnClickCalculateGrade(object sender, EventArgs e)
        {
            _studentMarksList.Items.Clear();
            int total;
            string grade = "";

            for(int i=0; i < list.Count; i++)
            {
                Student s1 = new Student();
                
                total = ((list[i].Exam1 + list[i].Exam2 + list[i].Exam3 + list[i].final) / 4);
                

                if (total >= 85 && total <= 100)
                {
                    grade = "A+";
                }
                else if (total >= 80 && total <= 84)
                {
                    grade = "A";
                }
                else if (total >= 75 && total <= 79)
                {
                    grade = "B+";
                }
                else if (total >= 70 && total <= 74)
                {
                    grade = "B";
                }
                else if (total >= 65 && total <= 69)
                {
                    grade = "B-";
                }
                else if (total >= 60 && total <= 64)
                {
                    grade = "C+";
                }
                else if (total >= 55 && total <= 59)
                {
                    grade = "C";
                }
                else if (total >= 50 && total <= 54)
                {
                    grade = "D";
                }
                else
                {
                    grade = "F";
                }

                _studentMarksList.Items.Add(list[i].FirstName + "                " + list[i].LastName + "       \t\t " + list[i].Exam1.ToString() + "             \t " + list[i].Exam2.ToString() + "              \t  " + list[i].Exam3.ToString() + "              \t  " + list[i].final.ToString() + "             \t " + total + "                \t" + grade);
            }
        }

    
       /// <summary>
       /// method to remove the selected record 
       /// </summary>
       /// <param name="sender"></param>
       /// <param name="e"></param>
        private void OnClickRemoveStudent(object sender, EventArgs e)
        {
            //listStudent.Items.Clear();
            int i = _studentMarksList.SelectedIndex;
            _studentMarksList.Items.RemoveAt(i);
        }

      
        private void _studentMarksList_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void MenuStrip1_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {

        }
    }
}
