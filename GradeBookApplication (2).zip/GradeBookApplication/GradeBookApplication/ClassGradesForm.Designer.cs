﻿namespace GradeBookApplication
{
    partial class ClassGradesForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.fileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.openToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.saveToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.addStudentToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.removeStudentToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.exitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this._studentMarksList = new System.Windows.Forms.ListBox();
            this._lbl1 = new System.Windows.Forms.Label();
            this._lbl2 = new System.Windows.Forms.Label();
            this._lblName = new System.Windows.Forms.Label();
            this._lbl3 = new System.Windows.Forms.Label();
            this._lblAvg = new System.Windows.Forms.Label();
            this._lblGrade = new System.Windows.Forms.Label();
            this._btnCalculate = new System.Windows.Forms.Button();
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.saveFileDialog1 = new System.Windows.Forms.SaveFileDialog();
            this.label1 = new System.Windows.Forms.Label();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.BackgroundImage = global::GradeBookApplication.Properties.Resources.homeBG;
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fileToolStripMenuItem,
            this.exitToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.RenderMode = System.Windows.Forms.ToolStripRenderMode.Professional;
            this.menuStrip1.Size = new System.Drawing.Size(800, 24);
            this.menuStrip1.TabIndex = 1;
            this.menuStrip1.Text = "menuStrip1";
            this.menuStrip1.ItemClicked += new System.Windows.Forms.ToolStripItemClickedEventHandler(this.MenuStrip1_ItemClicked);
            // 
            // fileToolStripMenuItem
            // 
            this.fileToolStripMenuItem.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.fileToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.openToolStripMenuItem,
            this.saveToolStripMenuItem,
            this.addStudentToolStripMenuItem,
            this.removeStudentToolStripMenuItem});
            this.fileToolStripMenuItem.Name = "fileToolStripMenuItem";
            this.fileToolStripMenuItem.Size = new System.Drawing.Size(37, 20);
            this.fileToolStripMenuItem.Text = "File";
            // 
            // openToolStripMenuItem
            // 
            this.openToolStripMenuItem.BackColor = System.Drawing.SystemColors.HotTrack;
            this.openToolStripMenuItem.Name = "openToolStripMenuItem";
            this.openToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.openToolStripMenuItem.Text = "Open";
            this.openToolStripMenuItem.Click += new System.EventHandler(this.OnClickOpen);
            // 
            // saveToolStripMenuItem
            // 
            this.saveToolStripMenuItem.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.saveToolStripMenuItem.Name = "saveToolStripMenuItem";
            this.saveToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.saveToolStripMenuItem.Text = "Save";
            this.saveToolStripMenuItem.Click += new System.EventHandler(this.OnClickSave);
            // 
            // addStudentToolStripMenuItem
            // 
            this.addStudentToolStripMenuItem.BackgroundImage = global::GradeBookApplication.Properties.Resources.img1;
            this.addStudentToolStripMenuItem.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.addStudentToolStripMenuItem.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.addStudentToolStripMenuItem.Name = "addStudentToolStripMenuItem";
            this.addStudentToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.addStudentToolStripMenuItem.Text = "Add Student";
            this.addStudentToolStripMenuItem.Click += new System.EventHandler(this.OnClickAdd);
            // 
            // removeStudentToolStripMenuItem
            // 
            this.removeStudentToolStripMenuItem.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.removeStudentToolStripMenuItem.Name = "removeStudentToolStripMenuItem";
            this.removeStudentToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.removeStudentToolStripMenuItem.Text = "Remove Student";
            this.removeStudentToolStripMenuItem.Click += new System.EventHandler(this.OnClickRemoveStudent);
            // 
            // exitToolStripMenuItem
            // 
            this.exitToolStripMenuItem.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.exitToolStripMenuItem.BackgroundImage = global::GradeBookApplication.Properties.Resources.bg2;
            this.exitToolStripMenuItem.Name = "exitToolStripMenuItem";
            this.exitToolStripMenuItem.Size = new System.Drawing.Size(37, 20);
            this.exitToolStripMenuItem.Text = "Exit";
            this.exitToolStripMenuItem.Click += new System.EventHandler(this.OnClickExit);
            // 
            // _studentMarksList
            // 
            this._studentMarksList.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this._studentMarksList.FormattingEnabled = true;
            this._studentMarksList.Location = new System.Drawing.Point(12, 112);
            this._studentMarksList.Name = "_studentMarksList";
            this._studentMarksList.Size = new System.Drawing.Size(747, 199);
            this._studentMarksList.TabIndex = 1;
            this._studentMarksList.SelectedIndexChanged += new System.EventHandler(this._studentMarksList_SelectedIndexChanged);
            this._studentMarksList.DoubleClick += new System.EventHandler(this.OnDoubleClick);
            // 
            // _lbl1
            // 
            this._lbl1.AutoSize = true;
            this._lbl1.Font = new System.Drawing.Font("Microsoft Tai Le", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this._lbl1.Location = new System.Drawing.Point(173, 81);
            this._lbl1.Name = "_lbl1";
            this._lbl1.Size = new System.Drawing.Size(48, 16);
            this._lbl1.TabIndex = 3;
            this._lbl1.Text = "Exam 1";
            // 
            // _lbl2
            // 
            this._lbl2.AutoSize = true;
            this._lbl2.Font = new System.Drawing.Font("Microsoft Tai Le", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this._lbl2.Location = new System.Drawing.Point(274, 81);
            this._lbl2.Name = "_lbl2";
            this._lbl2.Size = new System.Drawing.Size(48, 16);
            this._lbl2.TabIndex = 4;
            this._lbl2.Text = "Exam 2";
            // 
            // _lblName
            // 
            this._lblName.AutoSize = true;
            this._lblName.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this._lblName.Location = new System.Drawing.Point(66, 82);
            this._lblName.Name = "_lblName";
            this._lblName.Size = new System.Drawing.Size(45, 15);
            this._lblName.TabIndex = 5;
            this._lblName.Text = "Name";
            // 
            // _lbl3
            // 
            this._lbl3.AutoSize = true;
            this._lbl3.Font = new System.Drawing.Font("Microsoft Tai Le", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this._lbl3.Location = new System.Drawing.Point(377, 81);
            this._lbl3.Name = "_lbl3";
            this._lbl3.Size = new System.Drawing.Size(48, 16);
            this._lbl3.TabIndex = 6;
            this._lbl3.Text = "Exam 3";
            // 
            // _lblAvg
            // 
            this._lblAvg.AutoSize = true;
            this._lblAvg.Font = new System.Drawing.Font("Microsoft Tai Le", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this._lblAvg.Location = new System.Drawing.Point(565, 81);
            this._lblAvg.Name = "_lblAvg";
            this._lblAvg.Size = new System.Drawing.Size(55, 16);
            this._lblAvg.TabIndex = 7;
            this._lblAvg.Text = "Average";
            // 
            // _lblGrade
            // 
            this._lblGrade.AutoSize = true;
            this._lblGrade.Font = new System.Drawing.Font("Microsoft Tai Le", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this._lblGrade.Location = new System.Drawing.Point(660, 82);
            this._lblGrade.Name = "_lblGrade";
            this._lblGrade.Size = new System.Drawing.Size(75, 16);
            this._lblGrade.TabIndex = 8;
            this._lblGrade.Text = "Final Grades";
            // 
            // _btnCalculate
            // 
            this._btnCalculate.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this._btnCalculate.Location = new System.Drawing.Point(206, 365);
            this._btnCalculate.Name = "_btnCalculate";
            this._btnCalculate.Size = new System.Drawing.Size(295, 62);
            this._btnCalculate.TabIndex = 9;
            this._btnCalculate.Text = "Calculate Semester Grades";
            this._btnCalculate.UseVisualStyleBackColor = false;
            this._btnCalculate.Click += new System.EventHandler(this.OnClickCalculateGrade);
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.FileName = "openFileDialog1";
            this.openFileDialog1.FileOk += new System.ComponentModel.CancelEventHandler(this.OpenFileDialog1_FileOk);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Tai Le", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(476, 81);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(33, 16);
            this.label1.TabIndex = 10;
            this.label1.Text = "Final";
            // 
            // ClassGradesForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::GradeBookApplication.Properties.Resources.bg2;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.label1);
            this.Controls.Add(this._btnCalculate);
            this.Controls.Add(this._lblGrade);
            this.Controls.Add(this._lblAvg);
            this.Controls.Add(this._lbl3);
            this.Controls.Add(this._lblName);
            this.Controls.Add(this._lbl2);
            this.Controls.Add(this._lbl1);
            this.Controls.Add(this._studentMarksList);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "ClassGradesForm";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.ClassGradesForm_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem fileToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem openToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem saveToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem addStudentToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem removeStudentToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem exitToolStripMenuItem;
        private System.Windows.Forms.ListBox _studentMarksList;
        private System.Windows.Forms.Label _lbl1;
        private System.Windows.Forms.Label _lbl2;
        private System.Windows.Forms.Label _lblName;
        private System.Windows.Forms.Label _lbl3;
        private System.Windows.Forms.Label _lblAvg;
        private System.Windows.Forms.Label _lblGrade;
        private System.Windows.Forms.Button _btnCalculate;
        private System.Windows.Forms.OpenFileDialog openFileDialog1;
        private System.Windows.Forms.SaveFileDialog saveFileDialog1;
        private System.Windows.Forms.Label label1;
    }
}

