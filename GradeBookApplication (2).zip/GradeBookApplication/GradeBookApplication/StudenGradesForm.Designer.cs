﻿namespace GradeBookApplication
{
    partial class StudenGradesForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this._lblName = new System.Windows.Forms.Label();
            this._lblExam1 = new System.Windows.Forms.Label();
            this._lblExam2 = new System.Windows.Forms.Label();
            this._lblExam3 = new System.Windows.Forms.Label();
            this._lblFinal = new System.Windows.Forms.Label();
            this._btnAdd = new System.Windows.Forms.Button();
            this._txtFirstName = new System.Windows.Forms.TextBox();
            this._txtExam1 = new System.Windows.Forms.TextBox();
            this._txtExam2 = new System.Windows.Forms.TextBox();
            this._txtExam3 = new System.Windows.Forms.TextBox();
            this._txtFinal = new System.Windows.Forms.TextBox();
            this._txtLastName = new System.Windows.Forms.TextBox();
            this._lblLastName = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // _lblName
            // 
            this._lblName.AutoSize = true;
            this._lblName.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this._lblName.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this._lblName.Location = new System.Drawing.Point(57, 150);
            this._lblName.Name = "_lblName";
            this._lblName.Size = new System.Drawing.Size(79, 16);
            this._lblName.TabIndex = 1;
            this._lblName.Text = "FirstName";
            // 
            // _lblExam1
            // 
            this._lblExam1.AutoSize = true;
            this._lblExam1.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this._lblExam1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this._lblExam1.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this._lblExam1.Location = new System.Drawing.Point(415, 91);
            this._lblExam1.Name = "_lblExam1";
            this._lblExam1.Size = new System.Drawing.Size(54, 16);
            this._lblExam1.TabIndex = 5;
            this._lblExam1.Text = "Exam1";
            // 
            // _lblExam2
            // 
            this._lblExam2.AutoSize = true;
            this._lblExam2.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this._lblExam2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this._lblExam2.Location = new System.Drawing.Point(415, 134);
            this._lblExam2.Name = "_lblExam2";
            this._lblExam2.Size = new System.Drawing.Size(54, 16);
            this._lblExam2.TabIndex = 7;
            this._lblExam2.Text = "Exam2";
            // 
            // _lblExam3
            // 
            this._lblExam3.AutoSize = true;
            this._lblExam3.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this._lblExam3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this._lblExam3.Location = new System.Drawing.Point(415, 186);
            this._lblExam3.Name = "_lblExam3";
            this._lblExam3.Size = new System.Drawing.Size(58, 16);
            this._lblExam3.TabIndex = 9;
            this._lblExam3.Text = "Exam 3";
            // 
            // _lblFinal
            // 
            this._lblFinal.AutoSize = true;
            this._lblFinal.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this._lblFinal.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this._lblFinal.Location = new System.Drawing.Point(427, 245);
            this._lblFinal.Name = "_lblFinal";
            this._lblFinal.Size = new System.Drawing.Size(42, 16);
            this._lblFinal.TabIndex = 11;
            this._lblFinal.Text = "Final";
            // 
            // _btnAdd
            // 
            this._btnAdd.BackColor = System.Drawing.SystemColors.GrayText;
            this._btnAdd.Font = new System.Drawing.Font("Algerian", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this._btnAdd.Location = new System.Drawing.Point(287, 318);
            this._btnAdd.Name = "_btnAdd";
            this._btnAdd.Size = new System.Drawing.Size(168, 50);
            this._btnAdd.TabIndex = 13;
            this._btnAdd.Text = "ADD";
            this._btnAdd.UseVisualStyleBackColor = false;
            this._btnAdd.Click += new System.EventHandler(this.OnClickAdd);
            // 
            // _txtFirstName
            // 
            this._txtFirstName.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this._txtFirstName.Location = new System.Drawing.Point(179, 150);
            this._txtFirstName.Name = "_txtFirstName";
            this._txtFirstName.Size = new System.Drawing.Size(100, 20);
            this._txtFirstName.TabIndex = 2;
            // 
            // _txtExam1
            // 
            this._txtExam1.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this._txtExam1.Location = new System.Drawing.Point(540, 87);
            this._txtExam1.Name = "_txtExam1";
            this._txtExam1.Size = new System.Drawing.Size(100, 20);
            this._txtExam1.TabIndex = 6;
            // 
            // _txtExam2
            // 
            this._txtExam2.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this._txtExam2.Location = new System.Drawing.Point(540, 134);
            this._txtExam2.Name = "_txtExam2";
            this._txtExam2.Size = new System.Drawing.Size(100, 20);
            this._txtExam2.TabIndex = 8;
            // 
            // _txtExam3
            // 
            this._txtExam3.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this._txtExam3.Location = new System.Drawing.Point(540, 186);
            this._txtExam3.Name = "_txtExam3";
            this._txtExam3.Size = new System.Drawing.Size(100, 20);
            this._txtExam3.TabIndex = 10;
            // 
            // _txtFinal
            // 
            this._txtFinal.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this._txtFinal.Location = new System.Drawing.Point(540, 245);
            this._txtFinal.Name = "_txtFinal";
            this._txtFinal.Size = new System.Drawing.Size(100, 20);
            this._txtFinal.TabIndex = 12;
            // 
            // _txtLastName
            // 
            this._txtLastName.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this._txtLastName.Location = new System.Drawing.Point(179, 209);
            this._txtLastName.Name = "_txtLastName";
            this._txtLastName.Size = new System.Drawing.Size(100, 20);
            this._txtLastName.TabIndex = 4;
            // 
            // _lblLastName
            // 
            this._lblLastName.AutoSize = true;
            this._lblLastName.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this._lblLastName.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this._lblLastName.Location = new System.Drawing.Point(57, 209);
            this._lblLastName.Name = "_lblLastName";
            this._lblLastName.Size = new System.Drawing.Size(78, 16);
            this._lblLastName.TabIndex = 3;
            this._lblLastName.Text = "LastName";
            // 
            // StudenGradesForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.BackgroundImage = global::GradeBookApplication.Properties.Resources.homeBG;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this._lblLastName);
            this.Controls.Add(this._txtLastName);
            this.Controls.Add(this._txtFinal);
            this.Controls.Add(this._txtExam3);
            this.Controls.Add(this._txtExam2);
            this.Controls.Add(this._txtExam1);
            this.Controls.Add(this._txtFirstName);
            this.Controls.Add(this._btnAdd);
            this.Controls.Add(this._lblFinal);
            this.Controls.Add(this._lblExam3);
            this.Controls.Add(this._lblExam2);
            this.Controls.Add(this._lblExam1);
            this.Controls.Add(this._lblName);
            this.Name = "StudenGradesForm";
            this.Text = "StudenGradesForm";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label _lblName;
        private System.Windows.Forms.Label _lblExam1;
        private System.Windows.Forms.Label _lblExam2;
        private System.Windows.Forms.Label _lblExam3;
        private System.Windows.Forms.Label _lblFinal;
        private System.Windows.Forms.Button _btnAdd;
        private System.Windows.Forms.TextBox _txtFirstName;
        private System.Windows.Forms.TextBox _txtExam1;
        private System.Windows.Forms.TextBox _txtExam2;
        private System.Windows.Forms.TextBox _txtExam3;
        private System.Windows.Forms.TextBox _txtFinal;
        private System.Windows.Forms.TextBox _txtLastName;
        private System.Windows.Forms.Label _lblLastName;
    }
}